<?php
	require "create_database.php";
	require "create_user_table.php";
	require "create_item_table.php";
?>