<?php
	require "connect.php";
	$selectingDatabase = true;
	$connect->selectDB();
?>